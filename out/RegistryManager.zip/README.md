# roku registry manager

A small tool to fetch and delete registry section from roku devices.
